#!/bin/sh
spark-submit --class com.bigdata.sparksql.getOracledata --master local --deploy-mode client --jars $(echo  s3://venutrainingtest/drivers/*.jar | tr ' ' ',') s3://venutrainingtest/jars/sparkpocs_2.11-0.1.jar emp

